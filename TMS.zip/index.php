<?php

echo "Hi this is API"

?>